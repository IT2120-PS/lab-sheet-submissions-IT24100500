setwd("C:\\Users\\ASUS\\Downloads\\Compressed\\IT24100500")
getwd()
